package JavaAppsProject6;

import static com.db4o.Db4o.openFile;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import com.db4o.query.Query;

import model.Policy;
import model.Project;
import model.Solution;

public class QueryExecutor {
    @SuppressWarnings("deprecation")
	ObjectContainer db = openFile("project.db");

    public void runNQQueries() {
        System.out.println(">>> NQ: Proyek oleh Kemendagri Digital Transformation Project Sistem Informasi Nasional Program Infrastruktur Data");
        ObjectSet<Project> result = db.query(
            new Predicate<Project>() {
  
				private static final long serialVersionUID = 1L;

				public boolean match(Project p) {
                    return p.getManagedBy().getName().equals("Kementerian Dalam Negeri");
                }
            }
        );
        for (Object o : result) {
            System.out.println(((Project)o).getName());
        }
    }

    public void runQBEQueries() {
        System.out.println(">>> QBE: Solusi oleh Nutanix Virtualization Enhancement Hybrid Cloud Integration");
        Solution template = new Solution();
        template.setCreatedBy("Nutanix");
        ObjectSet<Object> result = db.queryByExample(template);
        for (Object o : result) {
            System.out.println(((Solution)o).getName());
        }
    }

    public void runSODAQueries() {
        System.out.println(">>> SODA: Kebijakan dari Kemendagri Kebijakan Akselerasi Transformasi Digital Kebijakan Pemanfaatan Infrastruktur TIK Nasional");
        Query q = db.query();
        q.constrain(Policy.class);
        q.descend("issuedByMinistry").descend("name").constrain("Kementerian Dalam Negeri");
        ObjectSet<?> result = q.execute();
        for (Object o : result) {
            System.out.println(((Policy)o).getPolicyName());
        }
    }
}

