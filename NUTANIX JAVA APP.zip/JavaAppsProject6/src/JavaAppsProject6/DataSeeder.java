package JavaAppsProject6;

import com.db4o.ObjectContainer;

import model.Bank;
import model.Ministry;
import model.Project;

public class DataSeeder {
	public static void seed(ObjectContainer db) {
        Bank rbl = new Bank();
        rbl.setName("RBL Bank");
        rbl.setCountry("India");
        rbl.setBankType("Komersial");

        Ministry kemendagri = new Ministry();
        kemendagri.setName("Kementerian Dalam Negeri");
        kemendagri.setSector("Pemerintahan");

        Project proyek1 = new Project();
        proyek1.setName("SIPD Development");
        proyek1.setManagedBy(kemendagri);
        proyek1.setFundedBy(rbl);

        db.store(rbl);
        db.store(kemendagri);
        db.store(proyek1);
        db.commit();
    }
}
