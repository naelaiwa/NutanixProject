package JavaAppsProject6;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			QueryExecutor executor = new QueryExecutor();

			System.out.println("=== CLI QUERY OQL ===");
			System.out.println("1. Run Navigational Queries");
			System.out.println("2. Run QBE Queries");
			System.out.println("3. Run SODA Queries");
			System.out.println("0. Exit");

			while (true) {
			    System.out.print("Pilih menu: ");
			    int choice = scanner.nextInt();

			    switch (choice) {
			        case 1:
			            executor.runNQQueries();
			            break;
			        case 2:
			            executor.runQBEQueries();
			            break;
			        case 3:
			            executor.runSODAQueries();
			            break;
			        case 0:
			            System.out.println("Keluar aplikasi.");
			            System.exit(0);
			        default:
			            System.out.println("Pilihan tidak valid.");
			    }
			}
		}
    }
}
