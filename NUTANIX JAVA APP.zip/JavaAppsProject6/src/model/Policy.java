package model;

public class Policy {
    private String policyId;
    private String policyName;
    private String issuedBy;
    private long year;
    private Ministry issuedByMinistry;

    // Getter & Setter
    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }

    public String getPolicyName() { return policyName; }
    public void setPolicyName(String policyName) { this.policyName = policyName; }

    public String getIssuedBy() { return issuedBy; }
    public void setIssuedBy(String issuedBy) { this.issuedBy = issuedBy; }

    public long getYear() { return year; }
    public void setYear(long year) { this.year = year; }

    public Ministry getIssuedByMinistry() { return issuedByMinistry; }
    public void setIssuedByMinistry(Ministry issuedByMinistry) { this.issuedByMinistry = issuedByMinistry; }
}
