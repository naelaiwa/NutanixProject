package model;

public class Solution {
    private String solutionId;
    private String name;
    private String category;
    private String createdBy;
    private DataManagement manages;

    // Getter & Setter
    public String getSolutionId() { return solutionId; }
    public void setSolutionId(String solutionId) { this.solutionId = solutionId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public DataManagement getManages() { return manages; }
    public void setManages(DataManagement manages) { this.manages = manages; }
}
