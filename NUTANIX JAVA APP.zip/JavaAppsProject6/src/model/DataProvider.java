package model;

public interface DataProvider {

	void provideData();

}
