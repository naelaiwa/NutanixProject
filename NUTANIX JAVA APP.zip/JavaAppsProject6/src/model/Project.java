package model;

import java.util.Date;

public class Project {
    private String projectId;
    private String name;
    private Date startDate;
    private Date endDate;
    private Ministry managedBy;
    private Bank fundedBy;

    // Getter & Setter
    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Date getStartDate() { return startDate; }
    public void setStartDate(Date startDate) { this.startDate = startDate; }

    public Date getEndDate() { return endDate; }
    public void setEndDate(Date endDate) { this.endDate = endDate; }

    public Ministry getManagedBy() { return managedBy; }
    public void setManagedBy(Ministry managedBy) { this.managedBy = managedBy; }

    public Bank getFundedBy() { return fundedBy; }
    public void setFundedBy(Bank fundedBy) { this.fundedBy = fundedBy; }
}
