package model;

public class OperationalImpact {
    private String impactId;
    private String impactType;
    private String description;

    private Solution impactOf;

    // Getter & Setter
    public String getImpactId() { return impactId; }
    public void setImpactId(String impactId) { this.impactId = impactId; }

    public String getImpactType() { return impactType; }
    public void setImpactType(String impactType) { this.impactType = impactType; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Solution getImpactOf() { return impactOf; }
    public void setImpactOf(Solution impactOf) { this.impactOf = impactOf; }
}
