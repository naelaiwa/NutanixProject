package model;

public interface Organization {
	String getOrganizationId();
    String getName();
    String getType();
    String getCountry();
    void getProfile();
}
