package model;

public class Ministry implements Organization {
    private String organizationId;
    private String name;
    private String type;
    private String country;
    private String sector;
    private String decreeNo;

    @Override
    public String getOrganizationId() { return organizationId; }
    @Override
    public String getName() { return name; }
    @Override
    public String getType() { return type; }
    @Override
    public String getCountry() { return country; }
    @Override
    public void getProfile() { System.out.println("Ministry Profile: " + name + ", " + sector); }

    // Getter & Setter
    public String getSector() { return sector; }
    public void setSector(String sector) { this.sector = sector; }

    public String getDecreeNo() { return decreeNo; }
    public void setDecreeNo(String decreeNo) { this.decreeNo = decreeNo; }
	public void setName(String string) {
		
	}
}