package model;

import java.util.Set;

public class DataManagement implements DataProvider {
    private String dmId;
    private String version;
    private String status;
    private Set<Infrastructure> infrastructures;
    private Set<Database> databases;

    @Override
    public void provideData() { System.out.println("Providing Data..."); }

    // Getter & Setter
    public String getDmId() { return dmId; }
    public void setDmId(String dmId) { this.dmId = dmId; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Set<Infrastructure> getInfrastructures() { return infrastructures; }
    public void setInfrastructures(Set<Infrastructure> infrastructures) { this.infrastructures = infrastructures; }

    public Set<Database> getDatabases() { return databases; }
    public void setDatabases(Set<Database> databases) { this.databases = databases; }
}
