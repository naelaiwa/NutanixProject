package model;

public class Database {
    private String dbId;
    private String name;
    private String engine;
    private String storage;

    // Getter & Setter
    public String getDbId() { return dbId; }
    public void setDbId(String dbId) { this.dbId = dbId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEngine() { return engine; }
    public void setEngine(String engine) { this.engine = engine; }

    public String getStorage() { return storage; }
    public void setStorage(String storage) { this.storage = storage; }
}
