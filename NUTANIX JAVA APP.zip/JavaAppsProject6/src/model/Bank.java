package model;

public class Bank implements Organization {
	private String organizationId;
    private String name;
    private String type;
    private String country;
    private String bankType;
    private String licenseNo;

    @Override
    public String getOrganizationId() { return organizationId; }
    @Override
    public String getName() { return name; }
    @Override
    public String getType() { return type; }
    @Override
    public String getCountry() { return country; }
    @Override
    public void getProfile() { System.out.println("Bank Profile: " + name + ", " + bankType); }

    // Getter & Setter
    public String getBankType() { return bankType; }
    public void setBankType(String bankType) { this.bankType = bankType; }

    public String getLicenseNo() { return licenseNo; }
    public void setLicenseNo(String licenseNo) { this.licenseNo = licenseNo; }
	public void setName(String string) {
		
	}
	public void setCountry(String string) {
		
	}
}
