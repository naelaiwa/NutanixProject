package model;

public class Regulation {
    private String regId;
    private String title;
    private String scope;
    private Policy partOf;

    // Getter & Setter
    public String getRegId() { return regId; }
    public void setRegId(String regId) { this.regId = regId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getScope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }

    public Policy getPartOf() { return partOf; }
    public void setPartOf(Policy partOf) { this.partOf = partOf; }
}
