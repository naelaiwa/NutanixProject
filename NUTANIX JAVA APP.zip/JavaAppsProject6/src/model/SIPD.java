package model;

public class SIPD {
    private String sipdId;
    private String region;
    private String version;
    private Solution uses;

    // Getter & Setter
    public String getSipdId() { return sipdId; }
    public void setSipdId(String sipdId) { this.sipdId = sipdId; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public Solution getUses() { return uses; }
    public void setUses(Solution uses) { this.uses = uses; }
}
